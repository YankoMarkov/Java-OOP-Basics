package wildFarm.animals;

abstract class Felime extends Mammal {
	
	Felime(String name, Double weight, String livingRegion) {
		super(name, weight, livingRegion);
	}
}
