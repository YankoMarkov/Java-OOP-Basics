package vehiclesExtension;

class Car extends Vehicle {
	
	public Car(double tankCapacity, double fuelQuantity, double fuelConsumption) {
		super(tankCapacity, fuelQuantity, fuelConsumption);
	}
}
