package vehiclesExtension;

class Truck extends Vehicle {
	
	public Truck(double tankCapacity, double fuelQuantity, double fuelConsumption) {
		super(tankCapacity, fuelQuantity, fuelConsumption);
	}
}
