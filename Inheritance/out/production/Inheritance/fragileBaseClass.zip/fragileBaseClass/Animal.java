package fragileBaseClass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Animal {
	private List<Food> foodEaten;
	
	public Animal() {
		this.setFoodEaten(new ArrayList<>());
	}
	
	public void setFoodEaten(List<Food> foodEaten) {
		this.foodEaten = foodEaten;
	}
	
	public final void eat(Food food) {
		this.foodEaten.add(food);
	}
	
	public void eatAll(Food[] foods) {
		Collections.addAll(this.foodEaten, foods);
	}
}
