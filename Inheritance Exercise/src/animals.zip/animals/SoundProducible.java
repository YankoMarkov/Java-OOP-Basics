package animals;

public interface SoundProducible {
	String produceSound();
}
